﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperadoresAtribuição
{
    class Program
    {
        static void Main(string[] args)
        {
            int valorA = 10;
            valorA += 10;
            valorA -= 10;
            valorA *= 3;
            valorA /= 3;
            valorA %= 4;

            valorA = valorA + 10;
            valorA = valorA - 10;
            valorA = valorA * 10;
            valorA = valorA / 10;
            valorA = valorA % 10;


        }
    }
}
