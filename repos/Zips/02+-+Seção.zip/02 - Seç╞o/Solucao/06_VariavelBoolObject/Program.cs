﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_VariavelBoolObject
{
    class Program
    {
        static void Main(string[] args)
        {
            bool meuBool = true;
            System.Boolean meuBool2 = false;

            System.Object meuObjeto = 2;
            object meuObjeto2 = "String";
        }
    }
}
