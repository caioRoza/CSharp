﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_VariavelCharString
{
    class Program
    {
        static void Main(string[] args)
        {
            char meuChar = '3';
            string meuString = "Olá Mundo!";

            Console.Write(meuString);
            Console.ReadKey();
        }
    }
}
