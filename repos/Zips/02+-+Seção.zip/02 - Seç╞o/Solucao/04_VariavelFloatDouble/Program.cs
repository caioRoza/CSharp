﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_VariavelFloatDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            float meuFloat = 3.0f;
            double meuDouble = 3.1;
            decimal meuDecimal = 3.2m;


        }
    }
}
