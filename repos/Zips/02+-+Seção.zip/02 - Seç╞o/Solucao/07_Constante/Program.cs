﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_Constante
{
    class Program
    {
        static void Main(string[] args)
        {
            const bool Porta = true;

            Console.WriteLine(Porta);
            Console.ReadKey();
        }
    }
}
