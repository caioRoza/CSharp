﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11_EntradaSaida
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.Write("Nome");
            Console.WriteLine("Nome");
            Console.Write("Nome");
            Console.WriteLine("Nome");
            Console.Write("Nome");
            Console.WriteLine("Nome");
            */

            /*
            int CodigoASCII = Console.Read();
            char Letra = (char)CodigoASCII;

            Console.WriteLine("Código ASCII: " + CodigoASCII + " - Letra: " + Letra);
            */

            /*
            ConsoleKeyInfo Letra = Console.ReadKey();
            Console.WriteLine("Tecla digitada: " + Letra.KeyChar);
            */
            
            /*
            string Frase = Console.ReadLine();
            Console.WriteLine(Frase);
            Console.ReadKey();
            */
        }
    }
}
