﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Variavel
{
    class Program
    {
        static void Main(string[] args)
        {
            byte meuByte;
            System.Byte meuByte2;

            meuByte = 9;

            sbyte meuSByte = -128;
        }
    }
}
