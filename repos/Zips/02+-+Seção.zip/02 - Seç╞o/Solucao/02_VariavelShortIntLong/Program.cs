﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_VariavelShortIntLong
{
    class Program
    {
        static void Main(string[] args)
        {
            short meuShort = 10;
            System.Int16 meuShort2 = 20;

            int meuInt;
            long meuLong;

            Console.Write(meuShort + meuShort2);
            Console.ReadKey();

        }
    }
}
