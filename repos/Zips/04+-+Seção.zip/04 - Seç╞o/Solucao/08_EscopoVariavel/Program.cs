﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_EscopoVariavel
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;
            int i;


            while (true)
            {
                if (true)
                {
                    int a;
                    Calcular();
                    
                }
                
            }
            i = 10;
        }

        static void Calcular()
        {
            int e;
        }
    }
}
