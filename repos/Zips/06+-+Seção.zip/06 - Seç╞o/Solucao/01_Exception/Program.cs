﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome = "José";
            Console.WriteLine("Olá Mundo!");

            nome = "Elias";


            Console.ReadKey();
        }
    }
}
