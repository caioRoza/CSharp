﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S2E1___EntradaSaida
{
    class Program
    {
        static void Main(string[] args)
        {
            string EntradaNome, EntradaIdade;

            Console.Write("Digite o seu nome: ");
            EntradaNome = Console.ReadLine();
            Console.Write("Digite a sua idade: ");
            EntradaIdade = Console.ReadLine();

            int IdadeNumero = int.Parse(EntradaIdade);
            int AnoNascimento = DateTime.Now.Year - IdadeNumero;

            Console.WriteLine("--------------------------------------");

            Console.WriteLine("Seu nome: " + EntradaNome);
            Console.WriteLine("O ano aproximado de nascimento é: " + AnoNascimento);


            Console.ReadKey();
        }
    }
}
