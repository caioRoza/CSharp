﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_Estatico
{
    class Carro
    {
        public static int QuantidadeCarrosProduzidos;
        public string Marca;
        public string Modelo;
        public string Cor;

        public void AbrirPorta()
        {

        }
    }
}
