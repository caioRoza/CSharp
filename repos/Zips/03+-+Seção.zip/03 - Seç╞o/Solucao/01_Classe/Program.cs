﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _01_Classe.Veiculo;


namespace _01_Classe
{
    class Program
    {
        static void Main(string[] args)
        {
            Veiculo.Carro carro1 = new Carro();
            _01_Classe.Veiculo.Carro carro2 = new Carro();
            Carro carro3 = new Carro();
            

            Console.WriteLine("Marca: " + carro1.Marca);
            carro1.Marca = "Ford";
            Console.WriteLine("Marca: " + carro1.Marca);


            Console.WriteLine("Luzes Internas: " + carro1.LuzesInternas);
            carro1.AbrirPorta();
            Console.WriteLine("Luzes Internas: " + carro1.LuzesInternas);

            
            string statusFarol = carro1.AcenderFarolAutomaticamente();
            Console.WriteLine("Status do Farol: " + statusFarol);



            Console.ReadKey();
        }
    }
}
