﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_Construtor
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro carro = new Carro();
            Carro carro2 = new Carro("Fiat", "Uno", 2010);
        }
    }
}
