﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _04_Polimorfismo.Biblioteca;

namespace _04_Polimorfismo
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro carro = new Carro();
            Moto moto = new Moto();
            Veiculo veiculo = new Veiculo();

            MoverObjeto(moto);

            Console.WriteLine("------------");
            MoverObjetoPoli(moto);
            MoverObjetoPoli(carro);
            MoverObjetoPoli(veiculo);
            Console.ReadKey();
        }

        static void MoverObjetoPoli(Veiculo obj)
        {
            obj.Mover();
        }

        static void MoverObjeto(Carro carro)
        {
            Console.WriteLine("MoverObjeto -> Carro");
            carro.Mover();
        }
        static void MoverObjeto(Moto moto)
        {
            Console.WriteLine("MoverObjeto -> Moto");
            moto.Mover();
        }
        static void MoverObjeto(Veiculo vei)
        {
            Console.WriteLine("MoverObjeto -> Veiculo");
            vei.Mover();
        }

    }
}
