﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Heranca.Biblioteca
{
    class Veiculo
    {
        public string Marca;
        public string Modelo;
        public int QuantidadeMaxPassageiros;
        public int Ano;

        public void Mover()
        {

        }
    }
}
