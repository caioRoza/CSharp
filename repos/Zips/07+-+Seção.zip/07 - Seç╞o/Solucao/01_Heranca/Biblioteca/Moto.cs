﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Heranca.Biblioteca
{
    class Moto : Veiculo
    {
        public int Rodas = 2;
    }
}
