﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Polimorfismo.Biblioteca.Derivada
{
    class Carro : Veiculo
    {
        public override void Mover()
        {
            Console.Write("Carro se movendo!!!!");
        }
    }
}
