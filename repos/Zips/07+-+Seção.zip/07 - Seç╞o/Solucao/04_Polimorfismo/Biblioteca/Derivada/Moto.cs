﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Polimorfismo.Biblioteca.Derivada
{
    class Moto : Veiculo
    {
        public override void Mover()
        {
            Console.Write("Moto se movendo!!!!");
        }
    }
}
