﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Polimorfismo
{
    class Program
    {
        static void Main(string[] args)
        {
            Biblioteca.Derivada.Moto moto = new Biblioteca.Derivada.Moto();
            MoverVeiculo(moto);

            Biblioteca.Derivada.Carro carro = new Biblioteca.Derivada.Carro();
            MoverVeiculo(carro);

            Console.ReadKey();
        }
        
        public static void MoverVeiculo(Biblioteca.Veiculo veiculo)
        {
            veiculo.Mover();
        }

    }
}
