﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_ComentarioTODO
{
    class Calculo
    {
        public void Exponenciacao()
        {
            // TODO Implementar o algoritmo de Exponenciacao.
        }
        public void Soma()
        {

        }
        public void Divisao()
        {

        }
    }
}
