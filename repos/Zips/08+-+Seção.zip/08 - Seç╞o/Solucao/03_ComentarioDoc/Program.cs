﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_ComentarioDoc
{
    class Program
    {
        static void Main(string[] args)
        {
            Veiculo veic = new Veiculo();
            veic.Mover(1);
            
        }
    }
}
