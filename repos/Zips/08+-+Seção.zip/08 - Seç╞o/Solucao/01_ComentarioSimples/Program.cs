﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_ComentarioSimples
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Texto de exemplo.");// Na linha abaixo será apresentado um texto na tela do usuário.
        }
    }
}
