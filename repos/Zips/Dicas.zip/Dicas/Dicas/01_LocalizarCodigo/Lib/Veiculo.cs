﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_LocalizarCodigo.Lib
{
    class Veiculo
    {
        public static void Mover()
        {
            Console.WriteLine("Veiculo > Mover");
        }
    }
}
