﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] marcasFamosas = { "Ferrari", "Google", "Coca-cola" };

            string[] nomes = new string[6];
            nomes[0] = "José";
            nomes[1] = "Maria";
        }
    }
}
