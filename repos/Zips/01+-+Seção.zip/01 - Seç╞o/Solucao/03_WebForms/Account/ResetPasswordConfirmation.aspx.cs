﻿using System.Web.UI;

namespace _03_WebForms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}