﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_03_WebForms.Startup))]
namespace _03_WebForms
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
